"""
Positive-Negative neuron parameter extraction from EEG signals.

Converts preprocessed EEG data into (a, b, c) PN parameters suitable
for QDNU A-Gate quantum circuits.

Model:
    da/dt = -λ_a · a + f(t)(1 - a)    # Excitatory state
    dc/dt = +λ_c · c + f(t)(1 - c)    # Inhibitory state
    b = phase(f(t))                    # Hilbert phase
"""

from openbci_eeg.pn_extraction.dynamics import (
    extract_pn_single,
    extract_pn_multichannel,
)
from openbci_eeg.pn_extraction.envelope import rms_envelope, normalize_envelope
from openbci_eeg.pn_extraction.io import (
    save_pn_parameters,
    load_pn_parameters,
    pn_to_qdnu_format,
)

__all__ = [
    "extract_pn_single",
    "extract_pn_multichannel",
    "rms_envelope",
    "normalize_envelope",
    "save_pn_parameters",
    "load_pn_parameters",
    "pn_to_qdnu_format",
]
