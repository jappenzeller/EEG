# CLAUDE.md — openbci-eeg

## What This Is

Standalone EEG acquisition pipeline: OpenBCI Cyton+Daisy → preprocessing → PN parameter extraction → QDNU quantum circuit analysis. Separate repo from QDNU; communicates via PN data contract (JSON/npz).

## Architecture

```
OpenBCI Cyton+Daisy (16-ch, 125 Hz, 24-bit)
         │
    BrainFlow API
         │
    Preprocessing (MNE-Python)
    ├── Notch 60 Hz
    ├── Bandpass 0.5-50 Hz
    └── ICA artifact removal
         │
    PN Extraction
    ├── RMS envelope → driving function f(t)
    ├── Hilbert → phase b
    └── ODE solver → (a, c) states
         │
    ┌────┴────┐
    │         │
  S3 raw   QDNU Bridge
    │       ├── A-Gate circuits
    │       ├── Template fidelity
    │       └── Seizure prediction
    │
  DynamoDB metadata
```

## Key Commands

```bash
# Install
pip install -e ".[dev,quantum]"

# Test (no hardware needed)
pytest

# Record (synthetic)
openbci-eeg test-board --synthetic
openbci-eeg record --synthetic --duration 60 --subject S001

# Record (real hardware)
openbci-eeg record --duration 300 --subject S001 --port /dev/ttyUSB0
```

## Module Map

| Module | Purpose | Hardware needed? |
|--------|---------|-----------------|
| `acquisition/board.py` | BrainFlow connection, streaming, recording | Yes (or --synthetic) |
| `acquisition/synthetic.py` | Fake data + signal injection for testing | No |
| `preprocessing/convert.py` | BrainFlow ↔ MNE conversion | No |
| `preprocessing/filters.py` | Notch, bandpass, full pipeline | No |
| `preprocessing/artifacts.py` | Threshold rejection, ICA, bad channels | No |
| `pn_extraction/dynamics.py` | PN ODE solver (Euler, RK4) | No |
| `pn_extraction/envelope.py` | RMS envelope, normalization | No |
| `pn_extraction/io.py` | Save/load PN params, QDNU format | No |
| `bridge/agate.py` | A-Gate circuit creation, fidelity | No (needs qiskit) |
| `bridge/templates.py` | Template library for classification | No |
| `aws/storage.py` | S3 upload/download | No (needs AWS creds) |
| `aws/metadata.py` | DynamoDB session tracking | No (needs AWS creds) |
| `paradigms/oddball.py` | P300 oddball protocol | No |
| `paradigms/sternberg.py` | STM/IQ Sternberg task | No |
| `paradigms/meditation.py` | Gamma/meditation protocol | No |

## Data Contract (openbci-eeg → QDNU)

```python
{
    "metadata": {
        "subject_id": "S001",
        "session_id": "20260215_1430",
        "sample_rate": 125,
        "channels": ["Fp1", ..., "O2"],
        "pn_config": {"lambda_a": 0.1, "lambda_c": 0.05, ...}
    },
    "pn_parameters": {
        "Fp1": {"a": [...], "b": [...], "c": [...]},
        ...
    },
    "timestamps": [...]
}
```

## PN Model

```
da/dt = -λ_a · a + f(t)(1 - a)    # Excitatory
dc/dt = +λ_c · c + f(t)(1 - c)    # Inhibitory
b = phase(hilbert(eeg))            # Phase
f(t) = normalize(rms_envelope(eeg)) # Driving function
```

## Hardware Specs

- Board: Cyton+Daisy, 16 differential channels
- ADC: ADS1299, 24-bit
- Sample rate: 125 Hz (16-ch) / 250 Hz (8-ch)
- Nyquist: 62.5 Hz (limits high gamma)
- Electrodes: Gold cup + Ten20 paste
- Target impedance: <10 kΩ
- Montage: Fp1, Fp2, F3, F4, F7, F8, T7, T8, C3, C4, P7, P8, P3, P4, O1, O2
- Ref: A1/A2 (earlobes), Ground: AFz

## Testing

```bash
pytest                              # All tests
pytest tests/test_pn_extraction/    # Just PN tests
pytest -m "not hardware"            # Skip hardware tests
pytest -m "not aws"                 # Skip AWS tests
```

## Priorities

1. PN extraction pipeline (testable now with synthetic data)
2. Preprocessing pipeline
3. QDNU bridge + seizure prediction templates
4. AWS infrastructure
5. Hardware acquisition (when parts arrive)
